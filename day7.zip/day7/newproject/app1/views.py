from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

from .forms import ContactForm,CalculatorForm


def home(request):
    return render(request, 'open_page.html')

def calculator(request):
    if request.method == 'GET':
        form = CalculatorForm(request.GET)
        if form.is_valid():
            num1 = form.cleaned_data['num1']
            num2 = form.cleaned_data['num2']
            op = form.cleaned_data['op']
            if op == 'add':
                response = int(num1) + int(num2)
            elif op == 'sub':
                response = int(num1) - int(num2)
            elif op == 'mul':
                response = int(num1) * int(num2)
            elif op == 'div':
                response = int(num1) / int(num2)
            else:
                response = "Please enter a valid operator"
            return render(request, 'home.html', {'result': response})
    else:
        form = CalculatorForm()
        return render(request, 'home.html',{'form':form})

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            return HttpResponse(f"Hi {name}, your email :{email} and message :{message}. We'll get back to you soon!")
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})