from django import forms

class ContactForm(forms.Form):
    name = forms.CharField(label='Name', max_length=100)
    email = forms.EmailField(label='Email')
    message = forms.CharField(label='Message', widget=forms.Textarea)

class CalculatorForm(forms.Form):
    num1 = forms.IntegerField(label='Number 1')
    num2 = forms.IntegerField(label='Number 2')
    op = forms.ChoiceField(label='Operator', choices=[('add', 'Add'), ('sub', 'Subtract'), ('mul', 'Multiply'), ('div', 'Divide')])