from django.contrib import admin

from .models import Budget

admin.site.register(Budget)
