import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="akhi",
    database="Training"
)

print("Connected!",conn)

cursor = conn.cursor()

def create_dtable():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL
    )
    """)
    conn.commit()

def insert_rows():
    sql = "INSERT INTO users (email, password) VALUES (%s, %s)"
    email = input("Enter Email: ")
    password = input("Enter Password: ")
    val = (email, password)
    cursor.execute(sql, val)
    conn.commit()
    print(cursor.rowcount, "record inserted.")

def view_data():
    cursor.execute("SELECT * FROM users")
    myresult = cursor.fetchall()
    for x in myresult:
        print(x)

def update_password(email):
    new_password = input("Enter Password: ")
    sql = "UPDATE users SET PASSWORD = (%s) WHERE EMAIL = (%s)"
    val = (new_password,email)
    cursor.execute(sql,val)
    conn.commit()

def delete_info():
    email = input("Enter the email which you want to delete: ")
    sql = "DELETE FROM USERS WHERE EMAIL = %s"
    val = (email,)
    cursor.execute(sql,val)
    conn.commit()

def close_connection():
    cursor.close()
    conn.close()

while True:
    print("1. Create Table\n2. Insert Rows\n3. View Data\n4. Update Password\n5. Delete an email\n6. Exit")
    choice = int(input("Enter your choice: "))
    if choice == 1:
        create_dtable()
    elif choice == 2:
        insert_rows()
    elif choice == 3:
        view_data()
    elif choice == 4:
        email = input("Please enter the email for which you want to update: ")
        update_password(email)
    elif choice == 5:
        delete_info()
    elif choice == 6:
        close_connection()
        break
    else:
        print("Please enter a valid choice!")





