from pymongo import MongoClient


def create_collection(db):
    db.create_collection("Student")
    return 
def connect_to_mongo():

    client = MongoClient("mongodb://localhost:27017/")
    db = client["Training"]
    return client,db

def insert_multiple_students(collection):
    n = int(input("Enter the number of students you want to enter: "))
    data = []
    for _ in range(n):
        document = {}
        while True:
            choice = int(input("Enter 1 to add column and data or 2 to stop: "))
            if choice == 1:
                column = input("Enter the column name: ")
                column_value = input("Enter the column value: ")
                document[column] = column_value
            else:
                break
        data.append(document)
    collection.insert_many(data)

def insert_single_student(collection):
    document = {}
    while True:
        choice = int(input("Enter 1 to add column and data or 2 to stop: "))
        if choice == 1:
            column = input("Enter the column name: ")
            column_value = input("Enter the column value: ")
            document[column] = column_value
        else:
            break
    collection.insert_one(document)

def find_all_students(collection):
    for student in collection.find():
        print(student)

def find_students_by_grade(collection,grade):
    students = collection.find({"Grade":grade})
    for student in students:
        print(student)

def update_student(collection):
    student_name = input("Enter the student Name: ")
    document = {}
    while True:
        choice = int(input("Enter 1 to add column and data or 2 to stop: "))
        if choice == 1:
            column = input("Enter the column name: ")
            column_value = input("Enter the column value: ")
            document[column] = column_value
        else:
            break
    collection.update_one({"name":student_name},{"$set":document})

def update_multiple_students(collection):
    n = int(input("Enter the number of students you want to update: "))
    for _ in range(n):
        student_name = input("Enter the student Name: ")
        document = {}
        while True:
            choice = int(input("Enter 1 to add column and data or 2 to stop: "))
            if choice == 1:
                column = input("Enter the column name: ")
                column_value = input("Enter the column value: ")
                document[column] = column_value
            else:
                break
        collection.update_one({"name":student_name},{"$set":document})

def delete_student(collection):
    student_name = input("Enter the student name: ")
    collection.delete_one({"name":student_name})

def delete_multiple_students(collection):
    grade = input("Enter the grade for which u want to delete: ")
    collection.delete_many({"Grade":grade})


client,db = connect_to_mongo()
# create_collection(db)
collection = db['Student']
while True:
    choice = int(input("Enter\n1.Insert one document.\n2.Insert multiple documents.\n3.Find all documents.\n4.Find documents by Grade.\n5.Update a document.\n6.Update multiple documents.\n7.Delete a document.\n8.Delete multiple documents.\n9.Exit\nEnter your choice: "))
    if choice == 1:
        insert_single_student(collection)
    elif choice == 2:
        insert_multiple_students(collection)
    elif choice == 3:
        find_all_students(collection)
    elif choice == 4:
        grade = input("Enter the grade: ")
        find_students_by_grade(collection,grade)
    elif choice == 5:
        update_student(collection)
    elif choice == 6:
        update_multiple_students(collection)
    elif choice == 7:
        delete_student(collection)
    elif choice == 8:
        delete_multiple_students(collection)
    elif choice == 9:
        break
    else:
        print("Please enter a valid choice!")
    




