from django.urls import path
from . import views


app_name = 'student'

urlpatterns = [
    path('home/', views.home, name='home'),
    path('addstudent/', views.create_student, name='add_student'),
    path('getstudents/',views.get_student,name='get_students'),
    path('updatestudent/<str:name>/',views.update_student_1,name='update_student'),
    path('deletestudent/<str:name>',views.delete_student_1,name='delete_student'),
]