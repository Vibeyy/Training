from django import forms
from .models import Students
class StudentForm(forms.ModelForm):
    class Meta:
        model = Students
        fields = ['name', 'grade', 'email', 'contact']

class DeletionForm(forms.ModelForm):
    class Meta:
        model = Students
        fields = ['name']