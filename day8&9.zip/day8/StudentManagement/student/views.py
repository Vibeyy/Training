from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from .forms import StudentForm, DeletionForm
from .models import Students
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import StudentSerializer

# Create your views here.

def redirect_to_main(request):
    return redirect( 'student:home')
def home(request):
    return render(request,'home.html')

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            if Students.objects.filter(email = form.cleaned_data['email']).exists():
                error_msg = "Email already exists"
                return render(request, 'add.html', {'form': form, 'error_msg': error_msg})
            else:
                form.save()
                return redirect('/student/addstudent')
        else:
            form = StudentForm()
            return render(request, 'add.html', {'form': form})
    else:
        return render(request, 'add.html', {'form': StudentForm()})
    

def get_students(request):
    students = Students.objects.all().values()
    return render(request, 'get.html', {'students': students})

def update_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            if Students.objects.filter(name = form.cleaned_data['name']).exists():
                student_data = Students.objects.get(name = form.cleaned_data['name'])
                student_data.name = form.cleaned_data['name']
                student_data.grade = form.cleaned_data['grade']
                student_data.email = form.cleaned_data['email']
                student_data.contact = form.cleaned_data['contact']
                student_data.save()
                return redirect('/student/updatestudent')
            else:
                error_msg = "Student does not exist"
                return render(request, 'update.html', {'form': form, 'error_msg': error_msg})
    else:
        form = StudentForm()
        return render(request, 'update.html', {'form': form})
    
def delete_student(request):
    if request.method == "POST":
        form = DeletionForm(request.POST)
        if form.is_valid():
            if Students.objects.filter(name = form.cleaned_data['name']).exists():
                student_data = Students.objects.get(name = form.cleaned_data['name'])
                student_data.delete()
                return redirect('/student/deletestudent')
            else:
                error_msg = "Student does not exist"
                return render(request, 'delete.html', {'form': form, 'error_msg': error_msg})
    else:
        form = DeletionForm()
        return render(request, 'delete.html', {'form': form})
    

@api_view(['GET'])
def ApiOverview(request):
    api_urls = {
        'Get all students': 'getstudents/',
        'Add a student': 'addstudent/',
        'Update a student': 'updatestudent/',
        'Delete a student': 'deletestudent/',
    }
    return Response(api_urls)


@api_view(['GET','POST'])
def create_student(request):
    if request.method == 'GET':
        students = Students.objects.all()
        serializer = StudentSerializer(students, many=True)
        return Response(serializer.data)
    else:
        serializer = StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(status=400)
    
@api_view(['GET'])
def get_student(request):
    if request.query_params:
        student = Students.objects.filter(**request.query_params.dict())
    else:
        student = Students.objects.all()
    if student:
        serializer = StudentSerializer(student, many=True)
        return Response(serializer.data)
    return Response(status=404)

@api_view(['POST'])
def update_student_1(request,name):
    student = Students.objects.get(name=name)
    serializer = StudentSerializer(student,data=request.data)
    if serializer.is_valid():    
        serializer.save()
        return Response(serializer.data)
    return Response(status=400)

@api_view(['DELETE'])
def delete_student_1(request,name):
    student = Students.objects.get(name=name);
    student.delete()
    return Response(status=204)